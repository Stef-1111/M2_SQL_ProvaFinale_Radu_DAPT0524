DROP DATABASE IF EXISTS ToysGroup;
CREATE DATABASE ToysGroup;
USE ToysGroup;

CREATE TABLE Product ( 
	ProductKey INT NOT NULL 
	, ProductName VARCHAR(100)
    , UnitaryCost DECIMAL(10, 2)
    , SubcategoryID INT
);
INSERT INTO Product
SELECT ProductKey, EnglishProductName, StandardCost, ProductSubcategoryKey
FROM adv.dimproduct
LIMIT 10000;

CREATE TABLE ProductCategory (
	CategoryID INT NOT NULL
	, CategoryName VARCHAR(100)
);
INSERT INTO ProductCategory
SELECT ProductCategoryKey, EnglishProductCategoryName
FROM adv.dimproductcategory
LIMIT 10000;

CREATE TABLE SubCategory (
	SubcategoryID INT NOT NULL
	, SubcategoryName VARCHAR(100)
    , CategoryID INT 
);
INSERT INTO SubCategory
SELECT ProductSubcategoryKey, EnglishProductSubcategoryName , ProductCategoryKey
FROM adv.dimproductsubcategory
LIMIT 10000;

CREATE TABLE Region(-- sales territory
	TerritoryKey INT NOT NULL-- Sales Territory key
	, Region VARCHAR(100) -- Sales Teorritory Group
	, Country  VARCHAR(100) -- Sales territory region
);
INSERT INTO Region
SELECT SalesTerritoryKey, SalesTerritoryGroup, SalesTerritoryCountry
FROM adv.dimsalesterritory
LIMIT 10000;

CREATE TABLE City ( -- Dimgeography
	GeographyKey INT NOT NULL
	, City VARCHAR(100)
    , TerritoryKey INT
);

INSERT INTO City
SELECT GeographyKey, City, SalesTerritoryKey
FROM adv.dimgeography
LIMIT 10000;


CREATE TABLE Sales (
	SalesOrderNumber VARCHAR(100) NOT NULL
    , SalesOrderLineNumber INT 
	, OrderDate DATE
	, ShippingDate DATE
	, Quantity INT
	, Amount DECIMAL(10, 2)
	, ProductKey  INT
    , TerritoryKey INT
);

INSERT INTO Sales
SELECT SalesOrderNumber, SalesOrderLineNumber,OrderDate ,ShipDate, OrderQuantity, SalesAmount, ProductKey, SalesTerritoryKey
FROM adv.factresellersales
LIMIT 10000;



-- Category
ALTER TABLE ProductCategory
ADD CONSTRAINT PK_CategoryID PRIMARY KEY (CategoryID);

-- SubCategory
ALTER TABLE SubCategory 
ADD CONSTRAINT PK_SubcategoryID PRIMARY KEY (SubcategoryID);
ALTER TABLE SubCategory
ADD CONSTRAINT FK_CategoryID FOREIGN KEY (CategoryID) REFERENCES ProductCategory(CategoryID);

-- Product 
ALTER TABLE Product 
ADD CONSTRAINT PK_ProductKey PRIMARY KEY (ProductKey);
ALTER TABLE Product 
ADD CONSTRAINT FK_SubcategoryID FOREIGN KEY (SubcategoryID) REFERENCES SubCategory(SubcategoryID);

-- Region 
ALTER TABLE Region
ADD CONSTRAINT PK_TerritoryKey PRIMARY KEY (TerritoryKey);

-- City
ALTER TABLE City
ADD CONSTRAINT PK_GeographyKey PRIMARY KEY (GeographyKey);
ALTER TABLE City
ADD CONSTRAINT FK_TerritoryKey FOREIGN KEY (TerritoryKey) REFERENCES Region(TerritoryKey);

-- Sales
ALTER TABLE Sales 
ADD CONSTRAINT PK_SalesOrderNumber PRIMARY KEY (SalesOrderNumber, SalesOrderLineNumber);
ALTER TABLE Sales 
ADD CONSTRAINT FK_TerritoryKey2 FOREIGN KEY (TerritoryKey) REFERENCES Region(TerritoryKey);
ALTER TABLE Sales 
ADD CONSTRAINT FK_ProductKey3 FOREIGN KEY (ProductKey) REFERENCES Product(ProductKey);

SELECT Sales.SalesOrderNumber, Sales.SalesOrderLineNumber, Sales.OrderDate, Sales.Quantity, Sales.Amount,
       Product.ProductName, Region.Region, Region.Country
FROM Sales
JOIN Product ON Sales.ProductKey = Product.ProductKey
JOIN Region ON Sales.TerritoryKey = Region.TerritoryKey;

SELECT Product.ProductName, SubCategory.SubcategoryName, ProductCategory.CategoryName
FROM Product
JOIN SubCategory ON Product.SubcategoryID = SubCategory.SubcategoryID
JOIN ProductCategory ON SubCategory.CategoryID = ProductCategory.CategoryID
;

-- QUERY 

/* 1) Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare
l’univocità dei valori di ciascuna PK (una query per tabella implementata). */
-- Seleziono la PK per ogni tabella, conto quante volte la PK viene riportata, se la tabella risulta vuota allora la chiave è uinivoca 
-- City 
SELECT
	GeographyKey
	, COUNT(GeographyKey) Conteggio
FROM city
GROUP BY GeographyKey
HAVING COUNT(GeographyKey) > 1;

 -- Product 
SELECT
	ProductKey
	, COUNT(ProductKey) Conteggio
FROM product
GROUP BY ProductKey
HAVING COUNT(ProductKey) > 1;
 -- Productcategory
SELECT
	CategoryID
	, COUNT(CategoryID) Conteggio
FROM productcategory
GROUP BY CategoryID
HAVING COUNT(CategoryID) > 1;
 -- Region
SELECT
	TerritoryKey
	, COUNT(TerritoryKey) Conteggio
FROM region
GROUP BY TerritoryKey
HAVING COUNT(TerritoryKey) > 1;
 -- Sales
SELECT
	SalesOrderNumber, SalesOrderLineNumber
	, COUNT(*) Conteggio
FROM sales
GROUP BY SalesOrderNumber, SalesOrderLineNumber
HAVING COUNT(*) > 1;
 -- Subcategory 
SELECT
	SubcategoryID
	, COUNT(SubcategoryID) Conteggio
FROM subcategory
GROUP BY SubcategoryID
HAVING COUNT(SubcategoryID) > 1;

/*2) Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del
prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo
booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o
meno (>180 -> True, <= 180 -> False)*/
-- NOTA: Si potrebbe aggiungere città per completezza, tuttavia, la diversificazione per città del prodotto porta il dato ad essere ridondande, allontanandoci dalla richiesta del problema. 
-- Ho quindi deciso di escludere città, che era tra l'altro un campo aggiuntivo
SELECT
	concat(s.SalesOrderNumber, ' - ', s.SalesOrderLineNumber) Cod_Documento
	, s.OrderDate
    , p.ProductName Product
    , c.CategoryName Category
    , r.Region 
    -- , ci.City
    , CASE
		WHEN datediff( NOW(), s.OrderDate) > 180 THEN TRUE
        ELSE FALSE
        END MoreThan180Days
FROM sales s
	INNER JOIN product p
	ON p.ProductKey = s.ProductKey
	INNER JOIN subcategory su
	ON p.SubcategoryID = su.SubcategoryID
	INNER JOIN productcategory c
	ON c.CategoryID = su.CategoryID
	INNER JOIN region r
	ON r.TerritoryKey = s.TerritoryKey 
	-- INNER JOIN city ci
	-- ON ci.TerritoryKey = r.TerritoryKey
    ;

/*3) Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle
vendite realizzate nell’ultimo anno censito. (ogni valore della condizione deve risultare da una query e
non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto e il totale
venduto.*/ 
/*NOTA: MediaIUltimo anno: 3.0225
	Qui di seguito propongo due differenti verisoni della stessa query. In particolare, il primo mostra una selezione dell'ultimo anno attraverso 
	limit 1. Invece nel secondo caso ho utilizzato la funzione MAX che mi è stato possibile implementare grazie ad un'altra subquery.
	entrambe le opzioni forniscono lo stesso risultato */

-- 1 Medoto - Funzione ORDER BY + LIMIT 1
SELECT 
	ProductName Product
	, SUM(s.quantity) SumQuantity
FROM sales s
INNER JOIN product p
ON p.ProductKey = s.ProductKey
group by p.ProductKey
HAVING SUM(s.quantity) > (SELECT QMUA
							FROM (
								SELECT 
									year(OrderDate)
									, avg(Quantity) QMUA
								FROM sales s
								GROUP BY YEAR(OrderDate)
								ORDER BY YEAR(OrderDate) DESC
								LIMIT 1
								) MediaQtUltimoAnno
							)
ORDER BY SumQuantity
;

-- 2 Metodo - Funzione MAX
SELECT 
    p.ProductName Product
	, SUM(s.Quantity) TotalQuantity
FROM sales s
INNER JOIN product p ON p.ProductKey = s.ProductKey
GROUP BY p.ProductKey
HAVING SUM(s.Quantity) > (
							SELECT MediaQtUltimoAnno.QMUA
							FROM (
									SELECT 
										YEAR(OrderDate) UltimoAnno,
										AVG(Quantity)QMUA
									FROM sales
									WHERE YEAR(OrderDate) = (
																SELECT MAX(YEAR(OrderDate)) 
																FROM sales
															)
															GROUP BY YEAR(OrderDate)
    ) MediaQtUltimoAnno
)
ORDER BY TotalQuantity;

/*4) Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.*/

/* NOTA - Ho inizialmente raggurppato per prodcutKey, venivano però riportati prodotti con lo stesso nome 
più volte in anno, il che rende la lettura molto difficile.
Ho notato che raggurppando per il nome prodotto, si ottevea il fatturato totale una volta sola. Probabilmente uno stesso prodotto veniva registrato in anni differenti con ProdctKey diversa

In Particolare, l'approccio con ProductKey mi restituisce 226 righe. Invece i prodotti distinti, considerato anche l'anno sembrano essere 192 

Per completezza, fornisco di seguito entrambe le versioni, Conscio che il productkey permette dei evitare ambiguità, soprattutto se un prodotto 
con lo stesso nome viene cambiato e diventa un prodotto differente nell'anno successivo

tuttavia, lascio anche la versione più "estetica", raggruppata per productName, considerando che fornisce un risultato che potrebbe comunque, in ambito business, 
soddisfare le esigenze dell'azienda. Infatti possiamo ipotizzare scenari nei quali il prodotto non cambia, ma la productkey deve cawmbiare per motivi legali o logistici. 
In quel caso è molto più utile considerare la seconda versione. 

Qualora invece siamo di fronte a cambi di productKey volontari, dobbiamo rifarci alla versione 1 come a quella più accurata. */

-- Versione 1: ProductKey
SELECT
	p.ProductKey ProdKey
    , p.ProductName Product
	, year(s.OrderDate) Year
	, SUM(s.Amount) TotalRevenues
FROM sales s
	INNER JOIN product p
	ON p.ProductKey = s.ProductKey
GROUP BY p.ProductKey, year(s.OrderDate)
ORDER BY Product, Year DESC
;


-- Versione 2: ProductName
SELECT
	p.ProductName Product
	, year(s.OrderDate) Year
	, SUM(s.Amount) TotalRevenues
FROM sales s
	INNER JOIN product p
	ON p.ProductKey = s.ProductKey
GROUP BY p.ProductName, year(s.OrderDate)
ORDER BY Product, Year DESC
;

/*5) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.*/

SELECT 
	r.Country
    , year(s.OrderDate) Year
    , SUM(s.Amount) TotRevenues
FROM sales s
	INNER JOIN region r
	ON r.TerritoryKey = s.TerritoryKey 
GROUP BY r.Country, year(s.OrderDate)
ORDER BY Year ASC, TotRevenues DESC 
    ;

/* 6) Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
CATEGORIA BIKES, Detiene il 53% del MarketShare*/

SELECT
	c.CategoryName Category
	, ROUND(SUM(s.Quantity) / (SELECT SUM(Quantity) FROM sales) * 100, 2) MarketShare
FROM sales s
	INNER JOIN product p
	ON p.ProductKey = s.ProductKey
	INNER JOIN subcategory su
	ON p.SubcategoryID = su.SubcategoryID
	INNER JOIN productcategory c
	ON c.CategoryID = su.CategoryID
GROUP BY c.CategoryID
ORDER BY MarketShare DESC 
LIMIT 1
;

/* 7) Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi 
differenti. */
-- NOTA: I due approcci risolutivi portano allo stesso numero di prodotti invenduti

-- Approccio 1: left outer join, tra product e sales -- 439 prodotti
SELECT p.ProductName ProdottoNonVenduto
FROM product p
	LEFT JOIN sales s
	ON s.ProductKey = p.ProductKey
WHERE s.Quantity IS NULL OR s.Quantity = 0
;

-- Sbuquery contenente i prodotti non venduti -- 439 Prodotti
SELECT 
    p.ProductName ProdottoNonVenduto
FROM product p
WHERE p.ProductKey NOT IN (
						SELECT s.ProductKey
						FROM sales s
						WHERE s.ProductKey = p.ProductKey AND s.Quantity > 0
						);
                        
/* 8) Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni
utili (codice prodotto, nome prodotto, nome categoria) */

CREATE VIEW VW_ST_Prodotti AS
	SELECT 
		p.ProductKey
		, p.ProductName Product
		, c.CategoryName Category
		, s.SubcategoryName Subcategory
	FROM product p
		INNER JOIN subcategory s
		ON p.SubcategoryID = s.SubcategoryID
		INNER JOIN productcategory c
		ON c.CategoryID = s.CategoryID
        ;
        
SELECT * 
FROM VW_ST_Prodotti 
;
        
/* 9) Creare una vista per le informazioni geografiche */

-- NOTA: La presenza di città crea ripetizioni. Ai fini della richiesta lascio la view principale senza, ne creo una che include anche la città
	CREATE VIEW VW_ST_InfoGeography AS
    SELECT 
		r.TerritoryKey
		, Region
		, Country
	FROM region r
        ;

SELECT *
FROM VW_ST_InfoGeography
;


CREATE VIEW VW_ST_InfoCity AS
    SELECT 
		r.TerritoryKey
		, Region
		, Country
		, City
	FROM region r
		INNER JOIN city c
		ON c.TerritoryKey = r.TerritoryKey
        ;
SELECT *
FROM VW_ST_InfoCity
;